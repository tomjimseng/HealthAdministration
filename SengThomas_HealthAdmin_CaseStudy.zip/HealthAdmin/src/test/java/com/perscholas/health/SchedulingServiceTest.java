package com.perscholas.health;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.sql.Date;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringRunner;

import com.perscholas.health.models.Scheduling;
import com.perscholas.health.repositories.SchedulingRepository;
import com.perscholas.health.services.SchedulingService;

@RunWith(SpringRunner.class)
@SpringBootTest
class SchedulingServiceTest {

	@Autowired
	private SchedulingService schedulingService;
	
	@MockBean
	private SchedulingRepository repository;
	
	
	@Test
	void createAppointmentTest() {
		String day = "2021-09-03";
		Date date = Date.valueOf(day);
		Scheduling appointment = new Scheduling(20, "Paul", "Pepper", "patient10@email.com", "324823492384", (java.sql.Date) date, "Doe");
		when(repository.save(appointment)).thenReturn(appointment);
		assertEquals(schedulingService.createAppointment(appointment), appointment);
	}
	
	@Test
	void removeAppointment() {
		String day = "2021-09-03";
		Date date = Date.valueOf(day);
		Scheduling appointment = new Scheduling(20, "Paul", "Pepper", "patient10@email.com", "324823492384", (java.sql.Date) date, "Doe");
		schedulingService.removeAppointment(20);
		verify(repository, times(1)).deleteById((long) 20);
	}
	
	@Test
	void getSchedulesTest() {
		String day = "2021-09-03";
		Date date = Date.valueOf(day);
		Scheduling appointment = new Scheduling(20, "Paul", "Pepper", "patient10@email.com", "324823492384", (java.sql.Date) date, "Doe");
		when(repository.findAll()).thenReturn(Stream.of(new Scheduling(20, "Paul", "Pepper", "patient10@email.com", "324823492384", (java.sql.Date) date, "Doe")).collect(Collectors.toList()));
		assertEquals(1, schedulingService.getSchedules().size());
	}
	
	@Test
	void findByPatientLastNameTest() {
		String day = "2021-09-03";
		Date date = Date.valueOf(day);
		Scheduling appointment = new Scheduling(20, "Paul", "Pepper", "patient10@email.com", "324823492384", (java.sql.Date) date, "Doe");
		when(repository.findByPatientLastName(appointment.getPatientLastName())).thenReturn(appointment);
		assertEquals( schedulingService.findByPatientLastName("Pepper"), appointment);
	}
	
	@Test
	void findByPatientFirstNameTest() {
		String day = "2021-09-03";
		Date date = Date.valueOf(day);
		Scheduling appointment = new Scheduling(20, "Paul", "Pepper", "patient10@email.com", "324823492384", (java.sql.Date) date, "Doe");
		when(repository.findByPatientFirstName(appointment.getPatientFirstName())).thenReturn(appointment);
		assertEquals( schedulingService.findByPatientFirstName("Paul"), appointment);
	}
	
}
