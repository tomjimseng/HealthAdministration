package com.perscholas.health;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringRunner;

import com.perscholas.health.models.Login;
import com.perscholas.health.repositories.LoginRepository;
import com.perscholas.health.services.LoginService;

@RunWith(SpringRunner.class)
@SpringBootTest
class LoginServiceTest {

	@Autowired
	private LoginService loginService;
	
	@MockBean
	private LoginRepository repository;
	
	@Test
	void findByEmailTest() {
		Login login = new Login("test@email.com", "pass123");
		Mockito.when(repository.findByEmail(login.getEmail())).thenReturn(login);
		assertEquals(loginService.findByEmail("test@email.com"), login);
	}

}
