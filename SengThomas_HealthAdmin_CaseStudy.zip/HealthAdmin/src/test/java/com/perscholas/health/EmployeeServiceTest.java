package com.perscholas.health;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringRunner;

import com.perscholas.health.models.Employee;
import com.perscholas.health.repositories.EmployeeRepository;
import com.perscholas.health.services.EmployeeService;

@RunWith(SpringRunner.class)
@SpringBootTest
class EmployeeServiceTest {

	@Autowired
	private EmployeeService employeeService;
	
	@MockBean 
	private EmployeeRepository repository;
	
	@Test
	void createEmployeeTest() {
		Employee employee = new Employee(50, "Jake", "Cake", "receptionist3@email.com", "8372194298479", "Radiology");
		when(repository.save(employee)).thenReturn(employee);
		assertEquals(employeeService.createEmployee(employee),employee);
	}
	
	@Test
	void removeEmployeeTest() {
		Employee employee = new Employee(50, "Jake", "Cake", "receptionist3@email.com", "8372194298479", "Radiology");
		employeeService.removeEmployee(50);
		verify(repository, times(1)).deleteById((long) 50);
	}
	
	@Test 
	void updateEmployeeTest() {
		Employee employee = new Employee(50, "Jake", "Cake", "receptionist3@email.com", "8372194298479", "Radiology");
		when(repository.save(employee)).thenReturn(employee);
		employee.setEmail("newemail@email.com");
		employeeService.updateEmployee(employee);
		assertEquals(employee.getEmail(), "newemail@email.com");
	}
	
	@Test 
	void getEmployeeTest() {
		when(repository.findAll()).thenReturn(Stream.of(new Employee(50, "Jake", "Cake", "receptionist3@email.com", "8372194298479", "Radiology")).collect(Collectors.toList()));
		assertEquals(1, employeeService.getEmployees().size());
	}
	
	@Test 
	void findByFirstNameTest() {
		Employee employee = new Employee(50, "Jake", "Cake", "receptionist3@email.com", "8372194298479", "Radiology");
		when(repository.findByFirstName(employee.getFirstName())).thenReturn(employee);
		assertEquals( employeeService.findByFirstName("Jake"), employee);
	}
	
	@Test 
	void findByLastNameTest() {
		Employee employee = new Employee(50, "Jake", "Cake", "receptionist3@email.com", "8372194298479", "Radiology");
		when(repository.findByLastName(employee.getLastName())).thenReturn(employee);
		assertEquals( employeeService.findByLastName("Cake"), employee);
	}

}
