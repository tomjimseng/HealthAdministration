package com.perscholas.health;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringRunner;

import com.perscholas.health.models.Contact;
import com.perscholas.health.repositories.ContactRepository;
import com.perscholas.health.services.ContactService;

@RunWith(SpringRunner.class)
@SpringBootTest
class ContactServiceTest {
	
	@Autowired
	private ContactService contactService;
	
	@MockBean
	private ContactRepository repository;
	
	@Test
	public void getMessageTest() {
		when(repository.findAll()).thenReturn(Stream.of(new Contact(40, "John Charles", "test1@email.com", "8329147392", "Hello World")).collect(Collectors.toList()));
		assertEquals(1, contactService.getMessages().size());
	}
	
	@Test
	public void createMessageTest() {
		Contact contact = new Contact(600, "John Charles", "test1@email.com", "8329147392", "Hello World");
		when(repository.save(contact)).thenReturn(contact);
		assertEquals(contact, contactService.createMessage(contact));
	}
	
	@Test
	public void removeMessageTest() {
		Contact contact = new Contact(600, "John Charles", "test1@email.com", "8329147392", "Hello World");
		contactService.removeMessage(contact);
		verify(repository, times(1)).delete(contact);
	}

}
