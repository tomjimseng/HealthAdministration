package com.perscholas.health;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import com.perscholas.health.models.Patient;

class PatientTest {

	@Test
	void getIdTest() {
		Patient patient = new Patient(80, "Joe", "Swanson", "joe@email.com", "8734892749", "O+", "Common Cold" );
		assertEquals(patient.getId(), 80);
	}
	
	@Test
	void setIdTest() {
		Patient patient = new Patient(80, "Joe", "Swanson", "joe@email.com", "8734892749", "O+", "Common Cold" );
		patient.setId(100);
		assertEquals(patient.getId(), 100);
	}
	
	@Test
	void getFirstNameTest() {
		Patient patient = new Patient(80, "Joe", "Swanson", "joe@email.com", "8734892749", "O+", "Common Cold" );
		assertEquals(patient.getFirstName(), "Joe");
	}
	
	@Test
	void setFirstNameTest() {
		Patient patient = new Patient(80, "Joe", "Swanson", "joe@email.com", "8734892749", "O+", "Common Cold" );
		patient.setFirstName("Moe");
		assertEquals(patient.getFirstName(), "Moe");
	}
	
	@Test
	void getLastNameTest() {
		Patient patient = new Patient(80, "Joe", "Swanson", "joe@email.com", "8734892749", "O+", "Common Cold" );
		assertEquals(patient.getLastName(), "Swanson");
	}
	
	@Test
	void setLastNameTest() {
		Patient patient = new Patient(80, "Joe", "Swanson", "joe@email.com", "8734892749", "O+", "Common Cold" );
		patient.setLastName("Bucks");
		assertEquals(patient.getLastName(), "Bucks");
	}
	
	@Test
	void getEmailTest() {
		Patient patient = new Patient(80, "Joe", "Swanson", "joe@email.com", "8734892749", "O+", "Common Cold" );
		assertEquals(patient.getEmail(), "joe@email.com");
	}
	
	@Test
	void setEmailTest() {
		Patient patient = new Patient(80, "Joe", "Swanson", "joe@email.com", "8734892749", "O+", "Common Cold" );
		patient.setEmail("moe@email.com");
		assertEquals(patient.getEmail(), "moe@email.com");
	}
	
	@Test
	void getPhoneTest() {
		Patient patient = new Patient(80, "Joe", "Swanson", "joe@email.com", "8734892749", "O+", "Common Cold" );
		assertEquals(patient.getPhone(), "8734892749");
	}
	
	@Test
	void setPhoneTest() {
		Patient patient = new Patient(80, "Joe", "Swanson", "joe@email.com", "8734892749", "O+", "Common Cold" );
		patient.setPhone("847234988");
		assertEquals(patient.getPhone(), "847234988");
	}
	
	@Test
	void getIllnessTest() {
		Patient patient = new Patient(80, "Joe", "Swanson", "joe@email.com", "8734892749", "O+", "Common Cold" );
		assertEquals(patient.getIllness(), "Common Cold");
	}
	
	@Test
	void setIllnessTest() {
		Patient patient = new Patient(80, "Joe", "Swanson", "joe@email.com", "8734892749", "O+", "Common Cold" );
		patient.setIllness("COVID");
		assertEquals(patient.getIllness(), "COVID");
	}
	
	@Test
	void getBloodTypeTest() {
		Patient patient = new Patient(80, "Joe", "Swanson", "joe@email.com", "8734892749", "O+", "Common Cold" );
		assertEquals(patient.getBloodType(), "O+");
	}
	
	@Test
	void setBloodTypeTest() {
		Patient patient = new Patient(80, "Joe", "Swanson", "joe@email.com", "8734892749", "O+", "Common Cold" );
		patient.setBloodType("O-");
		assertEquals(patient.getBloodType(), "O-");
	}

}
