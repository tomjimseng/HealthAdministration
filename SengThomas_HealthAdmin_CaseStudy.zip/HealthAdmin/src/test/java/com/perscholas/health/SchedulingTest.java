package com.perscholas.health;

import static org.junit.jupiter.api.Assertions.*;

import java.sql.Date;

import org.junit.jupiter.api.Test;

import com.perscholas.health.models.Scheduling;

class SchedulingTest {

	@Test
	void getPatientFirstNameTest() {
		String day = "2021-09-03";
		Date date = Date.valueOf(day);
		Scheduling appointment = new Scheduling(20, "Paul", "Pepper", "patient10@email.com", "324823492384", (java.sql.Date) date, "Doe");
		assertEquals(appointment.getPatientFirstName(), "Paul");
	}
	
	@Test
	void setPatientFirstNameTest() {
		String day = "2021-09-03";
		Date date = Date.valueOf(day);
		Scheduling appointment = new Scheduling(20, "Paul", "Pepper", "patient10@email.com", "324823492384", (java.sql.Date) date, "Doe");
		appointment.setPatientFirstName("Jack");
		assertEquals(appointment.getPatientFirstName(), "Jack");
	}
	
	@Test
	void getPatientLastNameTest() {
		String day = "2021-09-03";
		Date date = Date.valueOf(day);
		Scheduling appointment = new Scheduling(20, "Paul", "Pepper", "patient10@email.com", "324823492384", (java.sql.Date) date, "Doe");
		assertEquals(appointment.getPatientLastName(), "Pepper");
	}
	
	@Test
	void setPatientLastNameTest() {
		String day = "2021-09-03";
		Date date = Date.valueOf(day);
		Scheduling appointment = new Scheduling(20, "Paul", "Pepper", "patient10@email.com", "324823492384", (java.sql.Date) date, "Doe");
		appointment.setPatientLastName("Jack");
		assertEquals(appointment.getPatientLastName(), "Jack");
	}
	
	@Test
	void getPatientEmailTest() {
		String day = "2021-09-03";
		Date date = Date.valueOf(day);
		Scheduling appointment = new Scheduling(20, "Paul", "Pepper", "patient10@email.com", "324823492384", (java.sql.Date) date, "Doe");
		assertEquals(appointment.getPatientEmail(), "patient10@email.com");
	}
	
	@Test
	void setPatientEmailTest() {
		String day = "2021-09-03";
		Date date = Date.valueOf(day);
		Scheduling appointment = new Scheduling(20, "Paul", "Pepper", "patient10@email.com", "324823492384", (java.sql.Date) date, "Doe");
		appointment.setPatientEmail("patient20@email.com");
		assertEquals(appointment.getPatientEmail(), "patient20@email.com");
	}
	
	@Test
	void getPatientPhoneTest() {
		String day = "2021-09-03";
		Date date = Date.valueOf(day);
		Scheduling appointment = new Scheduling(20, "Paul", "Pepper", "patient10@email.com", "324823492384", (java.sql.Date) date, "Doe");
		assertEquals(appointment.getPatientPhone(), "324823492384");
	}
	
	@Test
	void setPatientPhoneTest() {
		String day = "2021-09-03";
		Date date = Date.valueOf(day);
		Scheduling appointment = new Scheduling(20, "Paul", "Pepper", "patient10@email.com", "324823492384", (java.sql.Date) date, "Doe");
		appointment.setPatientPhone("21342147890");
		assertEquals(appointment.getPatientPhone(), "21342147890");
	}
	
	@Test
	void getDateTest() {
		String day = "2021-09-03";
		Date date = Date.valueOf(day);
		Scheduling appointment = new Scheduling(20, "Paul", "Pepper", "patient10@email.com", "324823492384", (java.sql.Date) date, "Doe");
		assertEquals(appointment.getDate(), date);
	}
	
	@Test
	void setDateTest() {
		String day = "2021-09-03";
		Date date = Date.valueOf(day);
		Date date2 = Date.valueOf("2021-09-20");
		Scheduling appointment = new Scheduling(20, "Paul", "Pepper", "patient10@email.com", "324823492384", (java.sql.Date) date, "Doe");
		appointment.setDate(date2);
		assertEquals(appointment.getDate(), date2);
	}
	
	@Test
	void getDoctorLastNameTest() {
		String day = "2021-09-03";
		Date date = Date.valueOf(day);
		Scheduling appointment = new Scheduling(20, "Paul", "Pepper", "patient10@email.com", "324823492384", (java.sql.Date) date, "Doe");
		assertEquals(appointment.getDoctorLastName(), "Doe");
	}
	
	@Test
	void setDoctorLastNameTest() {
		String day = "2021-09-03";
		Date date = Date.valueOf(day);
		Scheduling appointment = new Scheduling(20, "Paul", "Pepper", "patient10@email.com", "324823492384", (java.sql.Date) date, "Doe");
		appointment.setDoctorLastName("Brown");
		assertEquals(appointment.getDoctorLastName(), "Brown");
	}
	
	@Test
	void getScheduleIdTest() {
		String day = "2021-09-03";
		Date date = Date.valueOf(day);
		Scheduling appointment = new Scheduling(20, "Paul", "Pepper", "patient10@email.com", "324823492384", (java.sql.Date) date, "Doe");
		assertEquals(appointment.getScheduleId(), 20);
	}
	
	@Test
	void setScheduleIdTest() {
		String day = "2021-09-03";
		Date date = Date.valueOf(day);
		Scheduling appointment = new Scheduling(20, "Paul", "Pepper", "patient10@email.com", "324823492384", (java.sql.Date) date, "Doe");
		appointment.setScheduleId(40);
		assertEquals(appointment.getScheduleId(), 40);
	}

}
