package com.perscholas.health;

import static org.junit.Assert.assertEquals;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import com.perscholas.health.models.Contact;
 
@SpringBootTest
class ContactTests {
	
	@Test
	void getEmailTest() {
		Contact contact = new Contact(600, "John Charles", "test1@email.com", "8329147392", "Hello World");
		assertEquals(contact.getEmail(), "test1@email.com");
	}
	
	@Test
	void setEmailTest() {
		Contact contact = new Contact(600, "John Charles", "test1@email.com", "8329147392", "Hello World");
		contact.setEmail("johnC@email.com");
		assertEquals(contact.getEmail(), "johnC@email.com");
	}
	
	@Test
	void getFullNameTest() {
		Contact contact = new Contact(600, "John Charles", "test1@email.com", "8329147392", "Hello World");
		assertEquals(contact.getFullName(), "John Charles");
	}
	
	@Test
	void setFullNameTest() {
		Contact contact = new Contact(600, "John Charles", "test1@email.com", "8329147392", "Hello World");
		contact.setFullName("Charles John");
		assertEquals(contact.getFullName(), "Charles John");
	}

	@Test
	void getIdTest() {
		Contact contact = new Contact(600, "John Charles", "test1@email.com", "8329147392", "Hello World");
		assertEquals(contact.getId(), 600);
	}
	
	@Test
	void setIdTest() {
		Contact contact = new Contact(600, "John Charles", "test1@email.com", "8329147392", "Hello World");
		contact.setId(601);
		assertEquals(contact.getId(), 601);
	}

	@Test
	void getPhoneTest() {
		Contact contact = new Contact(600, "John Charles", "test1@email.com", "8329147392", "Hello World");
		assertEquals(contact.getPhone(), "8329147392");
	}
	
	@Test
	void setPhoneTest() {
		Contact contact = new Contact(600, "John Charles", "test1@email.com", "8329147392", "Hello World");
		contact.setPhone("789793878");
		assertEquals(contact.getPhone(), "789793878");
	}

	@Test
	void getMessageTest() {
		Contact contact = new Contact(600, "John Charles", "test1@email.com", "8329147392", "Hello World");
		assertEquals(contact.getMessage(), "Hello World");
	}
	
	@Test
	void setMessageTest() {
		Contact contact = new Contact(600, "John Charles", "test1@email.com", "8329147392", "Hello World");
		contact.setMessage("Hello Java");
		assertEquals(contact.getMessage(), "Hello Java");
	}


}
