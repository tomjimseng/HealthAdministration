package com.perscholas.health;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import com.perscholas.health.models.Employee;

class EmployeeTest {

	@Test
	void getFirstNameTest() {
		Employee employee = new Employee(50, "Jake", "Cake", "receptionist3@email.com", "8372194298479", "Radiology");
		assertEquals(employee.getFirstName(), "Jake");
	}
	
	@Test
	void setFirstNameTest() {
		Employee employee = new Employee(50, "Jake", "Cake", "receptionist3@email.com", "8372194298479", "Radiology");
		employee.setFirstName("Mike");
		assertEquals(employee.getFirstName(), "Mike");
	}
	
	@Test
	void getLastNameTest() {
		Employee employee = new Employee(50, "Jake", "Cake", "receptionist3@email.com", "8372194298479", "Radiology");
		assertEquals(employee.getLastName(), "Cake");
	}
	
	@Test
	void setLasttNameTest() {
		Employee employee = new Employee(50, "Jake", "Cake", "receptionist3@email.com", "8372194298479", "Radiology");
		employee.setLastName("Bug");
		assertEquals(employee.getLastName(), "Bug");
	}
	
	@Test
	void getIdTest() {
		Employee employee = new Employee(50, "Jake", "Cake", "receptionist3@email.com", "8372194298479", "Radiology");
		assertEquals(employee.getId(), 50);
	}
	
	@Test
	void setIdTest() {
		Employee employee = new Employee(50, "Jake", "Cake", "receptionist3@email.com", "8372194298479", "Radiology");
		employee.setId(51);
		assertEquals(employee.getId(), 51);
	}
	
	@Test
	void getEmailTest() {
		Employee employee = new Employee(50, "Jake", "Cake", "receptionist3@email.com", "8372194298479", "Radiology");
		assertEquals(employee.getEmail(), "receptionist3@email.com");
	}
	
	@Test
	void setEmailTest() {
		Employee employee = new Employee(50, "Jake", "Cake", "receptionist3@email.com", "8372194298479", "Radiology");
		employee.setEmail("newEmail20@email.com");
		assertEquals(employee.getEmail(), "newEmail20@email.com");
	}
	
	@Test
	void getPhoneTest() {
		Employee employee = new Employee(50, "Jake", "Cake", "receptionist3@email.com", "8372194298479", "Radiology");
		assertEquals(employee.getPhone(), "8372194298479");
	}
	
	@Test
	void setPhoneTest() {
		Employee employee = new Employee(50, "Jake", "Cake", "receptionist3@email.com", "8372194298479", "Radiology");
		employee.setPhone("827493840890");
		assertEquals(employee.getPhone(), "827493840890");
	}
	
	@Test
	void getDepartmentTest() {
		Employee employee = new Employee(50, "Jake", "Cake", "receptionist3@email.com", "8372194298479", "Radiology");
		assertEquals(employee.getDepartment(), "Radiology");
	}
	
	@Test
	void setDepartmentTest() {
		Employee employee = new Employee(50, "Jake", "Cake", "receptionist3@email.com", "8372194298479", "Radiology");
		employee.setDepartment("ER");
		assertEquals(employee.getDepartment(), "ER");
	}

}
