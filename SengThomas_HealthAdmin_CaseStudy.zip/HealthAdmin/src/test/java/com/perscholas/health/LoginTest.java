package com.perscholas.health;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import com.perscholas.health.models.Login;

class LoginTest {

	@Test
	void getEmailTest() {
		Login login = new Login("test@email.com", "pass123");
		assertEquals(login.getEmail(), "test@email.com");
	}
	
	@Test
	void setEmailTest() {
		Login login = new Login("test@email.com", "pass123");
		login.setEmail("newEmail@email.com");
		assertEquals(login.getEmail(), "newEmail@email.com");
	}

	@Test
	void getIdTest() {
		Login login = new Login("test@email.com", "pass123");
		login.setId(300);
		assertEquals(login.getId(), 300);
	}
	
	@Test
	void setIdTest() {
		Login login = new Login("test@email.com", "pass123");
		login.setId(400);
		assertEquals(login.getId(), 400);
	}
	
	@Test
	void getPasswordTest() {
		Login login = new Login("test@email.com", "pass123");
		assertEquals(login.getPassword(), "pass123");
	}
	
	@Test
	void setPasswordTest() {
		Login login = new Login("test@email.com", "pass123");
		login.setPassword("newPass123");
		assertEquals(login.getPassword(), "newPass123");
	}

}
