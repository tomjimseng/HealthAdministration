package com.perscholas.health;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringRunner;

import com.perscholas.health.models.Patient;
import com.perscholas.health.repositories.PatientRepository;
import com.perscholas.health.services.PatientService;

@RunWith(SpringRunner.class)
@SpringBootTest
class PatientServiceTest {

	@Autowired
	private PatientService patientService;
	
	@MockBean
	private PatientRepository repository;
	
	@Test
	public void createPatientTest() {
		Patient patient = new Patient(80, "Joe", "Swanson", "joe@email.com", "8734892749", "O+", "Common Cold" );
		when(repository.save(patient)).thenReturn(patient);
		assertEquals(patientService.createPatient(patient), patient);
	}
	
	@Test
	public void removePatientTest() {
		Patient patient = new Patient(80, "Joe", "Swanson", "joe@email.com", "8734892749", "O+", "Common Cold" );
		patientService.removePatient(80);
		verify(repository, times(1)).deleteById((long) 80);
	}
	
	@Test
	public void findByFirstNameTest() {
		Patient patient = new Patient(80, "Joe", "Swanson", "joe@email.com", "8734892749", "O+", "Common Cold");
		when(repository.findByFirstName(patient.getFirstName())).thenReturn(patient);
		assertEquals( patientService.findByFirstName("Joe"), patient);
	}
	
	@Test
	void findByLastNameTest() {
		Patient patient = new Patient(80, "Joe", "Swanson", "joe@email.com", "8734892749", "O+", "Common Cold");
		when(repository.findByLastName(patient.getLastName())).thenReturn(patient);
		assertEquals( patientService.findByLastName("Swanson"), patient);
	}

}
