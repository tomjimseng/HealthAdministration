package com.perscholas.health.services;

import java.util.List;
import java.util.Optional;

import com.perscholas.health.models.Scheduling;

/**
 * Scheduling interface for Scheduling to provide application functionality.
 */

public interface SchedulingService {

	/**
	 * abstract method find schedule by specified schedule id.
	 */
	
	public Optional<Scheduling> findById(long scheduleId);
	
	/**
	 * abstract method find patient schedule by specified first name.
	 */
	
	public Scheduling findByPatientFirstName(String patientFirstName);
	
	/**
	 * abstract method find patient schedule by specified last name.
	 */
	
	public Scheduling findByPatientLastName(String patientLastName);
	
	/**
	 * abstract method create new appointment form patient.
	 */
	
	public Scheduling createAppointment(Scheduling scheduling);
	
	/**
	 * abstract method delete appointment method from the database.
	 */
	
	public void removeAppointment(long id);
	
	/**
	 * abstract method get all appointments from the scheduling database.
	 */
	
	public List<Scheduling> getSchedules();
}
